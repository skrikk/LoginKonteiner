{{/* Rakenduse nimi */}}
{{- define "loginapp.name" -}}
{{ .Release.Name }}
{{- end }}

{{/* Ühised labelid */}}
{{- define "loginapp.labels" -}}
app: {{ .Release.Name }}-frontend
chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}
